const axios = require("axios");
require("dotenv").config();

const BASE_URL = "https://nibssbyphoenix.onrender.com";

let cachedToken = null;
let tokenExpiresAt = 0;

async function getNibssToken() {
  if (cachedToken && Date.now() < tokenExpiresAt) {
    return cachedToken;
  }

  const response = await axios.post(
    `${BASE_URL}/api/auth/token`,
    {
      apiKey: process.env.NIBSS_API_KEY,
      apiSecret: process.env.NIBSS_API_SECRET,
    }
  );

  const data = response.data;
  const token =
    data.token ||
    data.accessToken ||
    data.access_token ||
    data.data?.token ||
    data.data?.accessToken;

  if (!token) {
    throw new Error("No token found in the API response.");
  }

  cachedToken = token;
  tokenExpiresAt = Date.now() + 50 * 60 * 1000;

  return cachedToken;
}

async function nibssRequest(method, path, body) {
  const token = await getNibssToken();

  try {
    const response = await axios({
      method,
      url: `${BASE_URL}${path}`,
      data: body,
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      timeout: 15000,
    });

    console.log("NIBSS response status:", response.status);
    console.log("NIBSS response body:", response.data);

    return response.data;
  } catch (error) {
    console.error(
      "NIBSS request failed:",
      error.response?.status || "No HTTP status",
      error.response?.data || error.message
    );

    throw error;
  }
}

module.exports = { getNibssToken, nibssRequest };