const express = require("express");
const pool = require("../db");
const auth = require("../middleware/auth");
const { nibssRequest } = require("../services/nibssService");

const router = express.Router();

// Verify a customer's BVN
router.post("/verify-bvn", auth, async (req, res) => {
  const { bvn } = req.body;

  // Accept exactly 11 digits
  if (typeof bvn !== "string" || !/^\d{11}$/.test(bvn)) {
    return res.status(400).json({
      message: "BVN must contain exactly 11 digits",
    });
  }

  try {
    // Send the BVN to the provider
    await nibssRequest("post", "/api/validateBvn", { bvn });

    // Only mark the customer verified after provider success
    await pool.query(
      `UPDATE customers
       SET verification_type = 'BVN',
           verification_status = 'verified'
       WHERE id = $1`,
      [req.user.customerId]
    );

    return res.json({
      message: "BVN verification successful",
      verification_status: "verified",
    });
  } catch (error) {
    const status = error.response?.status;

    if (status === 404) {
      return res.status(400).json({
        message: "BVN not found. Please check the sandbox test data.",
      });
    }

    console.error(
      "BVN verification failed:",
      status || error.message
    );

    return res.status(502).json({
      message: "Unable to complete BVN verification with the provider",
    });
  }
});

module.exports = router;