const express = require("express");
const pool = require("../db");
const auth = require("../middleware/auth");
const { nibssRequest } = require("../services/nibssService");

const router = express.Router();

// Get the logged-in customer's transaction history
router.get("/history", auth, async (req, res) => {
  try {
    const customerId = req.user.customerId;

    const result = await pool.query(
      `SELECT
         t.reference,
         t.transaction_type,
         t.amount,
         t.status,
         t.description,
         t.created_at,
         sender.account_number AS sender_account,
         recipient.account_number AS recipient_account
       FROM transactions t
       LEFT JOIN accounts sender
         ON t.sender_account_id = sender.id
       LEFT JOIN accounts recipient
         ON t.recipient_account_id = recipient.id
       WHERE sender.customer_id = $1
          OR recipient.customer_id = $1
       ORDER BY t.created_at DESC`,
      [customerId]
    );

    return res.status(200).json({
      message: "Transaction history retrieved successfully",
      count: result.rows.length,
      transactions: result.rows,
    });
  } catch (error) {
    console.error("Transaction history failed:", error.message);
    return res.status(500).json({
      message: "Unable to retrieve transaction history",
    });
  }
});

// Make an intra-bank transfer
router.post("/transfer", auth, async (req, res) => {
  const { recipient_account, amount } = req.body;
  if (req.body.test_mode === true) {
  return res.status(200).json({
    message: "Inter-bank transfer route is working",
    test_mode: true,
    transfer_sent: false
  });
}
  const customerId = req.user.customerId;
  const transferAmount = Number(amount);

  if (
    typeof recipient_account !== "string" ||
    !/^\d{10}$/.test(recipient_account) ||
    amount === undefined ||
    amount === null ||
    amount === "" ||
    !Number.isFinite(transferAmount) ||
    transferAmount <= 0 ||
    !Number.isSafeInteger(transferAmount * 100)
  ) {
    return res.status(400).json({
      message: "Provide a valid 10-digit recipient account and a positive amount with at most 2 decimal places",
    });
  }

  const client = await pool.connect();
  let transactionStarted = false;

  try {
    await client.query("BEGIN");
    transactionStarted = true;

    // Lock the sender's account while processing the transfer
    const senderResult = await client.query(
      `SELECT id, account_number, balance
       FROM accounts
       WHERE customer_id = $1
       FOR UPDATE`,
      [customerId]
    );

    const sender = senderResult.rows[0];

    if (!sender) {
      await client.query("ROLLBACK");
      transactionStarted = false;
      return res.status(404).json({
        message: "You do not have a bank account",
      });
    }

    // Lock the recipient account
    const recipientResult = await client.query(
      `SELECT id, account_number
       FROM accounts
       WHERE account_number = $1
       FOR UPDATE`,
      [recipient_account]
    );

    const recipient = recipientResult.rows[0];

    if (!recipient) {
      await client.query("ROLLBACK");
      transactionStarted = false;
      return res.status(404).json({
        message: "Recipient account not found",
      });
    }

    if (sender.id === recipient.id) {
      await client.query("ROLLBACK");
      transactionStarted = false;
      return res.status(400).json({
        message: "You cannot transfer money to your own account",
      });
    }

    if (Number(sender.balance) < transferAmount) {
      await client.query("ROLLBACK");
      transactionStarted = false;
      return res.status(400).json({
        message: "Insufficient balance",
      });
    }

    await client.query(
      `UPDATE accounts
       SET balance = balance - $1
       WHERE id = $2`,
      [transferAmount, sender.id]
    );

    await client.query(
      `UPDATE accounts
       SET balance = balance + $1
       WHERE id = $2`,
      [transferAmount, recipient.id]
    );

    const transactionResult = await client.query(
      `INSERT INTO transactions
       (sender_account_id, recipient_account_id, transaction_type,
        amount, status, description)
       VALUES ($1, $2, 'intra_bank', $3, 'successful', $4)
       RETURNING reference, amount, status, created_at`,
      [
        sender.id,
        recipient.id,
        transferAmount,
        "Intra-bank transfer",
      ]
    );

    await client.query("COMMIT");
    transactionStarted = false;

    return res.status(201).json({
      message: "Transfer successful",
      transaction: transactionResult.rows[0],
      recipient_account: recipient.account_number,
      amount: transferAmount,
      currency: "NGN",
    });
  } catch (error) {
    if (transactionStarted) {
      await client.query("ROLLBACK");
    }

    console.error("Transfer failed:", error.message);
    return res.status(500).json({
      message: "Unable to complete transfer",
    });
  } finally {
    client.release();
  }
});
/**
 * Inter-bank transfer through NIBSS
 */
const { nibssRequest } = require("../services/nibssService");

router.post("/inter-bank-transfer", auth, async (req, res) => {
  const { recipient_account, amount, test_mode } = req.body;
  const customerId = req.user.customerId;
  const transferAmount = Number(amount);

  // Safe test: confirm the route works without sending money.
  if (test_mode === true) {
    return res.status(200).json({
      message: "Inter-bank transfer route is working",
      test_mode: true,
      transfer_sent: false,
    });
  }

  // Real transfers remain disabled until NIBSS confirmation
  // and transaction-reference handling are implemented.
  return res.status(501).json({
    message:
      "Inter-bank transfers are not enabled yet. NIBSS transfer confirmation must be implemented first.",
    transfer_sent: false,
  });
});router.post("/inter-bank-transfer", auth, async (req, res) => {
  const { recipient_account, amount, test_mode } = req.body;
  const customerId = req.user.customerId;
  const transferAmount = Number(amount);

  // Safe test: confirm the route works without sending money.
  if (test_mode === true) {
    return res.status(200).json({
      message: "Inter-bank transfer route is working",
      test_mode: true,
      transfer_sent: false,
    });
  }

  // Real transfers remain disabled until NIBSS confirmation
  // and transaction-reference handling are implemented.
  return res.status(501).json({
    message:
      "Inter-bank transfers are not enabled yet. NIBSS transfer confirmation must be implemented first.",
    transfer_sent: false,
  });
});

  const { recipient_account, amount } = req.body;
  const customerId = req.user.customerId;
  const transferAmount = Number(amount);

  if (
    typeof recipient_account !== "string" ||
    !/^\d{10}$/.test(recipient_account) ||
    amount === undefined ||
    amount === null ||
    amount === "" ||
    !Number.isFinite(transferAmount) ||
    transferAmount <= 0 ||
    !Number.isSafeInteger(transferAmount * 100)
  ) {
    return res.status(400).json({
      message: "Provide a valid recipient account and amount",
    });
  }

  const senderResult = await pool.query(
    `SELECT id, account_number, balance
     FROM accounts
     WHERE customer_id = $1`,
    [customerId]
  );

  const sender = senderResult.rows[0];

  if (!sender) {
    return res.status(404).json({
      message: "You do not have a bank account",
    });
  }

  if (Number(sender.balance) < transferAmount) {
    return res.status(400).json({
      message: "Insufficient balance",
    });
  }

  try {
    const providerResult = await nibssRequest(
      "post",
      "/api/transfer",
      {
        from: sender.account_number,
        to: recipient_account,
        amount: transferAmount,
      }
    );

    return res.status(200).json({
      message: "NIBSS transfer request processed",
      provider_response: providerResult,
    });
  } catch (error) {
    console.error(
      "NIBSS inter-bank transfer failed:",
      error.response?.status,
      error.response?.data || error.message
    );

    return res.status(502).json({
      message: "NIBSS transfer failed or could not be confirmed",
    });
  }
});

module.exports = router;