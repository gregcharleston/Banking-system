const express = require("express");
const crypto = require("crypto");
const pool = require("../db");
const auth = require("../middleware/auth");
const { nibssRequest } = require("../services/nibssService");

const router = express.Router();

router.post("/open", auth, async (req, res) => {
  let client;
  let transactionStarted = false;

  try {
    const customerId = req.user.customerId;
    client = await pool.connect();

    await client.query("BEGIN");
    transactionStarted = true;

    const customerResult = await client.query(
      `SELECT id, verification_type, verification_status
       FROM customers
       WHERE id = $1
       FOR UPDATE`,
      [customerId]
    );

    const customer = customerResult.rows[0];

    if (!customer) {
      await client.query("ROLLBACK");
      transactionStarted = false;

      return res.status(404).json({
        message: "Customer not found",
      });
    }

    if (
      customer.verification_status !== "verified" ||
      !["BVN", "NIN"].includes(customer.verification_type)
    ) {
      await client.query("ROLLBACK");
      transactionStarted = false;

      return res.status(403).json({
        message: "Complete BVN or NIN verification first",
      });
    }

    const existingAccount = await client.query(
      "SELECT id FROM accounts WHERE customer_id = $1",
      [customerId]
    );

    if (existingAccount.rows.length > 0) {
      await client.query("ROLLBACK");
      transactionStarted = false;

      return res.status(409).json({
        message: "You already have a bank account",
      });
    }

    const accountNumber =
      "2" + crypto.randomInt(100000000, 1000000000).toString();

    const accountResult = await client.query(
      `INSERT INTO accounts
       (customer_id, account_number, balance)
       VALUES ($1, $2, $3)
       RETURNING id, customer_id, account_number, balance, created_at`,
      [customerId, accountNumber, 15000]
    );

    const account = accountResult.rows[0];

    await client.query(
      `INSERT INTO transactions
       (sender_account_id, recipient_account_id,
        transaction_type, amount, status, description)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        null,
        account.id,
        "funding",
        15000,
        "successful",
        "Initial account funding",
      ]
    );

    await client.query("COMMIT");
    transactionStarted = false;

    return res.status(201).json({
      message: "Account opened and funded successfully",
      account,
      initial_deposit: 15000,
      currency: "NGN",
    });
  } catch (error) {
    if (client && transactionStarted) {
      try {
        await client.query("ROLLBACK");
      } catch (rollbackError) {
        console.error("Rollback failed:", rollbackError.message);
      }
    }

    if (error.code === "23505") {
      return res.status(409).json({
        message: "An account already exists or an account number conflict occurred",
      });
    }

    console.error("Account opening failed:", error.message);

    return res.status(500).json({
      message: "Unable to open account",
    });
  } finally {
    if (client) {
      client.release();
    }
  }
});

router.get("/name-enquiry/:accountNumber", auth, async (req, res) => {
  const { accountNumber } = req.params;

  if (!/^\d{10}$/.test(accountNumber)) {
    return res.status(400).json({
      message: "Account number must contain exactly 10 digits",
    });
  }

  try {
    const result = await nibssRequest(
      "get",
      `/api/account/name-enquiry/${accountNumber}`
    );

    return res.status(200).json({
      message: "Account name enquiry completed",
      result,
    });
  } catch (error) {
    console.error("Account name enquiry failed:", {
      status: error.response?.status,
      message: error.message,
      response: error.response?.data,
    });

    return res.status(502).json({
      message: "Unable to complete account name enquiry",
    });
  }
});
/* Check the logged-in customer's account balance */
router.get("/balance", auth, async (req, res) => {
  try {
    const customerId = req.user.customerId;

    const result = await pool.query(
      `SELECT account_number, balance
       FROM accounts
       WHERE customer_id = $1`,
      [customerId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "No bank account found for this customer",
      });
    }

    return res.status(200).json({
      message: "Balance retrieved successfully",
      account_number: result.rows[0].account_number,
      balance: Number(result.rows[0].balance),
      currency: "NGN",
    });
  } catch (error) {
    console.error("Balance enquiry failed:", error.message);

    return res.status(500).json({
      message: "Unable to retrieve account balance",
    });
  }
});
module.exports = router;