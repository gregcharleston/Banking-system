const { getNibssToken } = require("../services/nibssService");

getNibssToken()
  .then((token) => {
    console.log("NIBSS token generated successfully:");
    console.log(token);
  })
  .catch((error) => {
    console.error(
      "Token generation failed:",
      error.response?.status,
      error.message
    );
    process.exitCode = 1;
  });