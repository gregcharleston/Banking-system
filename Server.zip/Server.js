const express = require("express");
const customerRoutes = require("./routes/customerRoutes");
const kycRoutes = require("./routes/kycRoutes");
const accountRoutes = require("./routes/accountRoutes");
const transactionRoutes = require("./routes/transactionRoutes");

const app = express();
const PORT = 5000;

app.use(express.json());
app.use("/api/customers", customerRoutes);
app.use("/api/kyc", kycRoutes);
app.use("/api/accounts", accountRoutes);
app.use("/api/transactions", transactionRoutes);

app.get("/", (req, res) => {
  res.json({ message: "Banking API is running!" });
});

app.get("/health", (req, res) => {
  res.json({ status: "healthy" });
});

app.use((req, res) => {
  res.status(404).json({ message: "Route not found" });
});

const server = app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

server.on("error", (err) => {
  console.error("Server error:", err.message);
});